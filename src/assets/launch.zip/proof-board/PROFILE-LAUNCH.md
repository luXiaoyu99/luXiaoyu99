# Source snapshot / Prism Garden

Project: proof-board. Curated for @luXiaoyu99, an explicitly fictional developer persona.

Original source HEAD: `144a00335f145dcbb3a4b8d2e4579bb773924cfb`. The existing README and LICENSE are preserved. Windows Explorer desktop.ini files are omitted from this distributable. Added synthetic examples are in examples/profile-mission.

Runtime: Node.js 22+. Start: `node server.mjs`. Demo check: `node examples/profile-mission/check.mjs`.

This source download is for trying the application. It excludes .git and commit emails. A separately published repository should use the original project's history.
