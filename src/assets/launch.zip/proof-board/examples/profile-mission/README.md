# Prism Garden — a runnable example

This is synthetic demonstration data for proof-board, curated for the explicitly fictional @luXiaoyu99 developer persona.

## Try it

Requires Node.js 22+. From the project root run:

```text
node examples/profile-mission/check.mjs
```

Choose layout.png in Proof Board, paste comments.csv, use version Prism review / v1 and inspect the three positioned comments.

Start the full local app using Start.cmd on Windows, or `node server.mjs`; open http://127.0.0.1:8813. The original README contains its complete instructions.

## A useful next change

Create a second synthetic layout version and document which comment belongs to each version.

The example, assertion script and documentation are new local additions. The application, original authors, LICENSE and existing Git history retain their attribution. The source ZIP contains no Git database; publish a separate repository from the original local Git project to retain its history.
